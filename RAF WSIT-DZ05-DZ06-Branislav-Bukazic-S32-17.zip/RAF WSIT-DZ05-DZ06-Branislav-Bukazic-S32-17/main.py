from flask import Flask
from flask import render_template

app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    f = open('RAFraspored.csv','r')
    redovi = f.readlines()
    svi_nastavnici = [red.split(',')[2] for red in redovi]
    sve_ucionice = [red.split(',')[6] for red in redovi]
    pojedinacni_nastavnici = []
    pojedinacne_ucionice = []
    for nastavnik in svi_nastavnici:
        if nastavnik not in pojedinacni_nastavnici:
            pojedinacni_nastavnici.append(nastavnik)
    for ucionica in sve_ucionice:
        if ucionica not in pojedinacne_ucionice:
            pojedinacne_ucionice.append(ucionica)

    svi_nastavnici = pojedinacni_nastavnici.sort()
    sve_ucionice = pojedinacne_ucionice.sort()

    return render_template("index.html",redovi = redovi, svi_nastavnici = pojedinacni_nastavnici, sve_ucionice = pojedinacne_ucionice)


if __name__ == '__main__':
	app.run(debug=True)